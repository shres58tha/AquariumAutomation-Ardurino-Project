#define abs(x) ((x)>0?(x):-(x))

/*  pinModeFast (pinNum)
    digitalWriteFast(pinNum, state) (sets or clears pin/port faster)
    pinModeFast(pinNum, mode) (sets pin/port as input or output faster)
    digitalReadFast(pinNum)(reads the state of pin/port faster)
    digitalToggleFast(pinNum)(toggles the state of pin/port faster)
*/
#include <digitalWriteFast.h>


#include <EEPROM.h>


#include <Servo.h>

// pin name        1   2   3   4   5   6  7    8   9   10  11  12  13  14   15         16
// signal          VSS VDD V0  RS  R/W E  DB0  DB1 DB2 DB3 DB4 DB5 DB6 DB7  LED+       LED-  
// value rt to lf  gnd  5v pot      5v     na  na  na  na                   10kReg5V   gnd
// 
// LiquidCrystal(27, 23, 24, 24, 25, 26);

#include <LiquidCrystal.h>
const int rs = 27, en = 26, d4 = 25, d5 = 24, d6 = 23, d7 = 22;
const int col=20, row=4;
LiquidCrystal lcd(rs, en, d4, d5, d6, d7); 


// ---- constant (won't change)
// pin layout Declarations

//input group
 const uint8_t setPinTemp =  A0;                             //pin to read from pot1         uint8_t = byte
 const uint8_t setPinLux = A1;                               //in A4*conversionFactor/1024   pin to read from pot2
 const uint8_t setPinFeedingInterval = A2;                   //                              pin to read from pot3
 const uint8_t setPinLightOnDuration = A3;                   //                              pin to read from pot4
 const uint8_t setPinReqPushButton = 22 ;                    //push and hold this pin to set parameters by rotaing pots pull to low using registor
//sensor read group
 const uint8_t currentPinTemp = A8;                          //pin to read from temp sensor
 const uint8_t currentPinLux = A9;                           //in A4*conversionFactor/1024   pin to read form ldr
 const uint8_t currentPin_pH = A10;                          //                              pin to read from pH meter

//output group
 const uint8_t controlPinHeater = 8;                         //(pwm not needed) heater default state low  while high cutoff the heater and aeration
 const uint8_t controlPinLightingLED = 9;                    // for controlling aquarium light normal is low.
 const uint8_t controlPinAlarm = 10 ;                        // pwm 0r digital mode for the alarm indicatro led and or buzzer
 const uint8_t controlPinFoodServo = 11;                     // pwn may be needed servo motor turn pin. Normal low. introduce feed when high

 const uint8_t onBoardLedPin = 13;                           //onBoard LED used to indicate operation state by blinking every x loops


//constants
 const uint8_t servoMinDegrees = 20;                         // the limits to servo movement
 const uint8_t servoMaxDegrees = 100;

// declare the lcd 2004 20 * 4 pins declarations

// variables ------------
 byte stateAlarm = LOW;
 byte stateHeatercontrolPin = LOW;                           // normal state is low  --> heater is on
 byte stateLightControlPin = LOW;
 byte stateFoodServoPin = LOW;                               // normal state is low  --> feed off 
 
//
 byte setTemp, currentTemp;  //in byte scaled 0-255           // set value can be saved in eeprom these needs to be byte not float
 byte setLux, currentLux;    //in byte scaled 0-255
 byte current_pH;            //scaled to byte range           // fix for display

 unsigned long setFeedInterval; 
 unsigned long setLightOnDuration;

// conversion  constants analog to set variable
 float convert2Temp = 5.0/256.0;
 float convert2Lux = 5.0/256.0;
 float convert2pH ;  // find range in data sheet and calculate this

//Servo  constants
Servo myservo;                                               // create servo object to control a servo
 int servoPosition = servoMinDegrees;                                      // the intial angle of the servo - starting at 0.
 int servoDegrees = 5;                                       // amount servo moves at each step
 byte servoSwitch = LOW ;                                    // motor off

//time variables
 unsigned long millisCurrent = 0;                            // stores the value of millis() in each iteration of loop()
 unsigned long millisLastRead = 0;                           // will store last time anlog input were read
 unsigned long millisLastCurrent = 0 ;

 unsigned long readInterval = 500 ;                          // milliseconds
 unsigned long currentInterval = 500;                        // millisLastRead = millisCurrent;
 unsigned long servoInterval = 0 ;

 unsigned long millisLastWrite = 0;                          // will store last time the sensor pins were read
 unsigned long millisLastServo = 0;                          // the time when the servo was last moved

 unsigned long millisLastFed = 500;                       // number of millisecs between blinks in millis
 unsigned long millisFoodInterval = 0;

 unsigned long onBoardLedBlink = 500;                       // number of millisecs between blinks in millis
 unsigned long millisLastBoardLed = 0;

 uint8_t millisOverflow = 0 ;


//========
void setup() {
  Serial.begin(9600);
  // so we know what sketch is running
  Serial.println("Starting SeveralThingsAtTheSameTimeAquyarium");

  lcd.begin(col, row);

 // set the Led pins as input analog all:
  pinMode(setPinReqPushButton, INPUT);
  pinMode(setPinTemp, INPUT);
  pinMode(setPinLux, INPUT);  
  pinMode(setPinFeedingInterval, INPUT);
  pinMode(setPinLightOnDuration, INPUT);  

  pinMode(currentPinTemp, INPUT);
  pinMode(currentPinLux, INPUT);  
  pinMode(currentPin_pH, INPUT);

  // set out pin all digital pwm enabled
  pinModeFast(controlPinHeater, OUTPUT);
  pinModeFast(controlPinLightingLED, OUTPUT);
  pinModeFast(controlPinAlarm, OUTPUT); 
  pinModeFast(controlPinFoodServo, OUTPUT);
  pinModeFast(onBoardLedPin, OUTPUT);   

  myservo.write(servoPosition);                             // sets the initial position
  myservo.attach(controlPinFoodServo);

  //set initial environment
  digitalWriteFast(controlPinHeater, LOW);                  //initial state of Heater pin heater is on
  digitalWriteFast(controlPinLightingLED, LOW);
  digitalWriteFast(controlPinAlarm, LOW); 
  digitalWriteFast(controlPinFoodServo, LOW);
  digitalWriteFast(onBoardLedPin, LOW);                     //initial state of LED pin  LED off

  // the variables should be saved for power failure and hard reboots in EEPROM
  //restore set values from EEPROM
  /*
  setTemp = EEPROM.read(0);
  setLux  = EEPROM.read(1);
  
  const int lower_8_bits = B00111111;
  byte SB = (a >> 6) & lower_6_bits;
  byte LSB = a & lower_6_bits;


  setPinFeedingInterval = EEPROM.read(2) *256 + EEPROM.read(3);  //255*256+255 = 65535 //unsigned int uint8_t
  setLightOnDuration = EEPROM.read(4)*256 +EEPROM.read(5);       // u long = 4,294,967,295 == 
  */
}
void loop() {
  //calls for action
  millisCurrent = millis();                                 //   note internal clock in millisecond
  while (digitalRead(setPinReqPushButton)==1) {             //normally setPinReqPushButton is low push and hold to set parameters while rotating pots
      ReadInputs();   
  }           
  ReadCurrents();

  ControlState();
  
  //OnBoardLedBlink();                                      //function call oviously should be expensive
  if ( millisCurrent -  millisLastBoardLed >= onBoardLedBlink) { // blink internal LED
      digitalToggleFast(onBoardLedPin);    //real Toggle here
      millisLastBoardLed += onBoardLedBlink;  //increment the millis
     }
}
void ReadInputs(){
    if (millisCurrent - millisLastRead >= readInterval) {   //for debounch or it may not be necessary at all readInterval should be small for smoothness of not needed at all 
        setTemp = analogRead(setPinTemp) /4 ;   //takes approx 100 micros each as per info on ardurino.cc
        setLux  = analogRead(setPinLux)  /4 ;   //scale 1024 values to 256
        setFeedInterval  = analogRead(setPinFeedingInterval)     ; //scale it to millis 
        setLightOnDuration  = analogRead(setPinLightOnDuration)  ; //scale it to millis 
        LCD_Display();
       }
    millisLastRead = millis();                             // putting most recent value of millis in last read one.
}
void ReadCurrents(){
    float tmpTemp = currentTemp , tmpLux = currentLux , tmp_pH = current_pH;
    if (millisCurrent - millisLastCurrent>= currentInterval) {  
      currentTemp = analogRead(currentPinTemp) * convert2Temp ; 
      currentLux  = analogRead(currentPinLux)  * convert2Lux  ;
      current_pH  = analogRead(currentPin_pH)  * convert2pH   ;
      LCD_Display();
      millisLastCurrent = millis() ;                         // putting most recent value of millis in last read one.
     }
}

void ControlState() {
  // heater control
  if ( stateHeatercontrolPin == LOW ){                        // pin low
      if ( currentTemp - setTemp  >= 1 )
        digitalToggleFast(controlPinHeater);             // becomes high
  }else {                                                     // pin high
      if ( currentTemp - setTemp  <= 1 )
        digitalToggleFast(controlPinHeater);             // becomes low
  }

  //Light control
  if ( stateLightControlPin == LOW ){                        // pin low
     if ( currentLux < setLux  ) {
        digitalToggleFast(controlPinLightingLED);         // becomes high
     }
  }else {                                                     // pin high
      if ( currentLux > setLux  ) {
         digitalToggleFast(controlPinLightingLED);              // becomes low
      }
  }
// pH temperature range alarm
    if (  abs(current_pH - 7) > 1 || abs (currentTemp - setTemp) > 3 ){                        
     alarm(HIGH);       
    } else {
      alarm(LOW);
    }
  
  // heater control
  if ( stateHeatercontrolPin == LOW ){                        // pin low
      if ( currentTemp - setTemp  >= 1 )
        digitalToggleFast(controlPinHeater);             // becomes high
  }else {                                                     // pin high
      if ( currentTemp - setTemp  <= 1 )
        digitalToggleFast(controlPinHeater);             // becomes low
  }  
// feed control  
  if ( (millisCurrent - millisLastFed) > millisFoodInterval ) {
      millisLastFed = millisCurrent + millisFoodInterval ;
      servoSwitch = HIGH;
  }


void LCD_Display() {
  lcd.setCursor(0, 0); 
  lcd.print("   current     Set ");
  lcd.setCursor(0, 1);
  lcd.print("temp ");  
  lcd.setCursor(0, 1);
  lcd.print("temp "); 
  
//  lcd.cursor(20, 1);
//  lcd.autoscroll();
//   for (int thisChar = 0; thisChar < 10; thisChar++) {
//     lcd.print(thisChar);
//     delay(500);
//   }
//   lcd.noAutoscroll();
//   lcd.clear();

}

void alarm( uint8_t state){
  if ( stateAlarm == LOW ){                        // pin low
      if ( state )
        digitalToggleFast( controlPinAlarm )             // becomes high
  }else {                                                     // pin high
      if ( !state )
        digitalToggleFast(controlPinAlarm);             // becomes low
  }
}

void servoSweep() {
  if(servoSwitch){
    if ( millisCurrent -  millisLastServo >= servoInterval) {
      millisLastServo += servoInterval;    // its time for another move
      servoPosition = servoPosition + servoDegrees;         // servoDegrees might be negative
      if ((servoPosition >= servoMaxDegrees) || (servoPosition <= servoMinDegrees))  {
        // if the servo is at either extreme change the sign of the degrees to make it move the other way
        servoDegrees = - servoDegrees;                      // reverse direction
        // and update the position to ensure it is within range
        servoPosition = servoPosition + servoDegrees;
       }
      // make the servo move to the next position
      myservo.write(servoPosition);
     // and record the time when the move happened
     }
   if ( servoDegrees <= servoMinDegrees) {
      servoSwitch = LOW;
   }
  }
}

// END