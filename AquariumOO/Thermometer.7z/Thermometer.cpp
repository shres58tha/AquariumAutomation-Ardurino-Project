#include "Thermometer.h"

uint8_t getCelsius(DeviceAddress ADDDRESS ){
    float tempC = oneWireSensors.getTempC(ADDDRESS);
    if(tempC == DEVICE_DISCONNECTED_C)  {
      Serial.println("Error: Could not read temperature data");
      return 0;
    }
    else return(uint8_t) tempC*10;
  }
}

uint8_t Thermo::getTargetVal(){
      return targetTemp ;
}
void Thermo::setTargetTemp(uint8_t t){
      targetTemp = t;
}
