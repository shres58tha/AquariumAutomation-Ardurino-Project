
#ifndef THERMO_H
#define THERMO_H
      #include <Arduino.h>
      #include <digitalWriteFast.h>    
      #include <stdint.h>
      #include <DallasTemperature.h>
      											//pin to read for temp sensor  digital one wire pin need to be defined will not allow    /* 
OneWire oneWire(13); // Pin=13 (we'll not actually use pin13)
DallasTemperature sensors(&oneWire);

void setup(void)  {
  Serial.begin(115200);

  // Runtime: 
  //  Change PIN value associated with OneWire 
  //  bus - From now on Pin 4 will be used
  oneWire.begin(4); 

  sensors.begin();
} 
*/
class Thermo{
	private:
      uint8_t targetTemp;
      //onewire object creation for thermometer
      //uint16_t inVal;
	public:
      Thermo(){}     //null constructor  not needed as no other constructor created by default
      uint8_t getTargetVal();
      uint16_t get(DeviceAddress ADDDRESS);
      void setTargetTemp(uint8_t t);
};
#endif /* THERMO_H */
